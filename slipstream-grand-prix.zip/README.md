# Slipstream Grand Prix

A cockpit-view Grand Prix career game that runs in the browser and installs like an app on phones and computers.

## What's in it

- **Career mode** across three series: Tier 1 Grand Prix World Series, Tier 2 Velocity Cup and Tier 3 Junior Formula Championship. Contract offers, promotions, and getting released if you underperform.
- **20 circuits**, each with qualifying (or skip it and start 20th) and a 5-lap race with laps of about 45 seconds.
- **Tyres and strategy**: five compounds, visible wear on all four tyres, and a mandatory 15-second pit stop.
- **Weather**: rain that arrives, passes or dries out mid-race, with slippery wet tracks.
- **Racing**: DRS zones, slipstreaming, collision penalties and damage, and track limits (more than 3 s off track costs 5 s).
- **Cockpit view** with a rear-view mirror, plus T-cam and chase cameras.
- **Three save slots**, graphics quality settings (Low / Medium / High), and engine sound that changes with gear shifts.

## Controls

| Action | Keyboard | Phone |
|---|---|---|
| Throttle | ↑ or W | GAS pedal |
| Brake / reverse | ↓ or S | BRAKE pedal |
| Steer | ← → or A D | Steering joystick |
| DRS | Space | DRS button |
| Pit this lap | P | BOX button |
| Tyres during a stop | 1–5 | Tap a tyre |
| Camera | C | Pause menu |
| Mirror on/off | V | Pause menu |
| Sound / pause | M / Esc | Pause button |

## Put it online with GitHub Pages

1. Create a new repository on GitHub, for example `slipstream-grand-prix`.
2. Upload these files to it, or push them with git:
   ```bash
   git remote add origin https://github.com/YOUR-NAME/slipstream-grand-prix.git
   git push -u origin main
   ```
3. In the repository, open **Settings → Pages** and set **Source** to **GitHub Actions**.
4. The included workflow deploys on every push to `main`. After a minute or two the game is live at
   `https://YOUR-NAME.github.io/slipstream-grand-prix/`.

## Install it as an app

Open the live link, then:

- **Android (Chrome):** menu → **Install app** (or **Add to Home screen**).
- **iPhone / iPad (Safari):** Share → **Add to Home Screen**.
- **Windows / Mac (Chrome or Edge):** click the install icon in the address bar.

It launches full screen in landscape. After the first visit it also works offline.

Your careers are saved in that browser or installed app on that device.

## Files

- `index.html`: the whole game
- `manifest.webmanifest` and `icons/`: app name, icon and launch settings
- `sw.js`: offline support
- `.github/workflows/pages.yml`: automatic deployment to GitHub Pages
